﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentAdmissionManagement
{
    class Student
    {
        private int studentId; private string studentName; private int age; private string course; private double admissionFee;
        public Student(int id, string name, int age, string course, double fee) { studentId = id; studentName = name; this.age = age; this.course = course; admissionFee = fee; }
        public void DisplayDetails() { Console.WriteLine("\nStudent Admission Details"); Console.WriteLine("Student ID : " + studentId); Console.WriteLine("Student Name : " + studentName); Console.WriteLine("Age : " + age); Console.WriteLine("Course : " + course); Console.WriteLine("Admission Fee : " + admissionFee); }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Student ID: "); int id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Student Name: "); string name = Console.ReadLine();
            Console.Write("Enter Age: ");
         
            int age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Course: "); string course = Console.ReadLine();
            Console.Write("Enter Admission Fee: "); double fee = Convert.ToDouble(Console.ReadLine());
            Student student = new Student(id, name, age, course, fee);
            student.DisplayDetails();
            Console.WriteLine("\nPress any key to exit..."); Console.ReadKey();
        }
    }
}

